#!/bin/bash

# Inicializar array de URLs enode
enodes=()

# Función para copiar plantillas a sus correspondientes directorios conf
copy_template() {
    local template_file="$1"
    local conf_dir="$2"

    cp -f "templates/$template_file" "conf/$conf_dir/$template_file"
    echo "Plantilla $template_file copiada a conf/$conf_dir/"
}

# Función para arrancar contenedores docker y esperar por URLs enode
start_and_wait_for_enode() {
    local service_name="$1"

    echo "Arrancando $service_name..."
    docker-compose up -d $service_name
    echo "Esperando durante 10 segundos..."
    sleep 10
    local pattern="enode:\/\/[^\s]+"
    local enode_url=$(docker-compose logs $service_name | grep -oP "$pattern" | awk '{print $1}' | head -n 1)

    while [ -z "$enode_url" ]; do
        echo "Reiniciando $service_name..."
        docker-compose up -d $service_name
        echo "Esperando durante 10 segundos..."
        sleep 10
        enode_url=$(docker-compose logs $service_name | grep -oP "$pattern" | awk '{print $1}' | head -n 1)
    done
    enodes+=($enode_url)

    echo "Enode URL para $service_name: $enode_url"
}

# Función para actualizar boot_nodes en los archivos toml correspondientes
update_boot_nodes() {
    local node_name=$1
    local conf_dir=$2
    local toml_file=$3

    echo "Actualizando bootnodes para $node_name..."
    awk -v boot_nodes="$BOOT_NODES" '{gsub(/#BOOT_NODES/, boot_nodes)}1' conf/$conf_dir/$toml_file > tmpfile && mv tmpfile conf/$conf_dir/$toml_file
}

# Copiar archivos de plantilla a sus directorios conf respectivos
copy_template "rpc.toml" "rpc"
copy_template "validator.toml" "validator"
copy_template "user0.toml" "user0"
copy_template "user1.toml" "user1"

# Arrancar contenedores Docker y esperar por URLs enode
start_and_wait_for_enode "rpc_node"
start_and_wait_for_enode "validator_node"
start_and_wait_for_enode "user0_node"
start_and_wait_for_enode "user1_node"

# Parar contenedores Docker
echo "Parando nodos..."
docker-compose stop


# Construir BOOT_NODES para la configuración
BOOT_NODES="bootnodes = ["
for ((i = 0; i < ${#enodes[@]}; i++)); do
    if [ $i -gt 0 ]; then
        BOOT_NODES+=","
    fi
    BOOT_NODES+="\n\"${enodes[$i]}\""
done
BOOT_NODES+="\n]"

# Formatear BOOT_NODES
BOOT_NODES="$(echo -e "$BOOT_NODES")"

# Actualizar boot_nodes en los archivos toml correspondientes
update_boot_nodes "rpc_node" "rpc" "rpc.toml"
update_boot_nodes "validator_node" "validator" "validator.toml"
update_boot_nodes "user0_node" "user0" "user0.toml"
update_boot_nodes "user1_node" "user1" "user1.toml"

# Reiniciar todos los contenedores Docker y esperar por URLs enode
start_and_wait_for_enode "rpc_node"
start_and_wait_for_enode "validator_node"
start_and_wait_for_enode "user0_node"
start_and_wait_for_enode "user1_node"

echo -e "\nArranque de blockchain completado"

